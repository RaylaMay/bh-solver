# DW6 test-first handoff — revision 1

Read `dw6/README.md`, then `dw6/spec/DW6_DEVELOPER_HANDOFF.md` and the acceptance specification.
The frozen package has 97 mandatory tests. The actual pre-DW6 baseline has 3 legacy
passes and 94 explicit missing-capability failures; no skips or collection errors.
Full observed outcomes are under `evidence/release-r1/`.

Manifest SHA-256: `c9eb72f084c00f4b820d7294b68f80ebdc0721f402ea9cfb5c65483f7ccca91a`
Obtain the trust anchor from the reviewer-controlled delivery record/checksum,
not an incoming candidate. Run this external copy against the exact candidate.
Do not amend the tests or regenerate the manifest without reviewer agreement.

The product is not implemented by this handoff. DW4/DW5 acceptance remains a
prerequisite. A passing software suite still needs the existing checks, native and
live-provider witness, and implementation review before integration.

`evidence/` includes working-tree identities, fixture checks, verifier challenges,
ordinary project checks, all authoring failures and earlier unreleased snapshots.
`evidence/evidence-manifest.json` hashes those records. The external archive checksum
identifies the complete delivery. Source-repository links in frozen documents are
rendered as literal references; consult the candidate repository for those files.
